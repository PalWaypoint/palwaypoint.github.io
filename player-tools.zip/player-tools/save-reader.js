// Read-only adapter. Upstream parser/decoder source and GPL license: vendor/NOTICE.md.
import {GvasFile,FReader,PALWORLD_TYPE_HINTS} from './vendor/gvas.js';
import {decompressSav} from './vendor/sav.js';
import {LEVEL_CUSTOM_PROPERTIES} from './vendor/paldata.js';
import {decompress} from './vendor/ooz-index.js';
export const val=p=>p?.value?.type!==undefined&&p.value.value!==undefined?p.value.value:p?.value;
const values=p=>val(p)?.values||[];
const uid=p=>String(val(p)||'');
const sp=c=>val(c.value.RawData)?.object?.SaveParameter?.value;
const num=(p,d=0)=>Number(val(p)??d);
export async function readSave(buffer){
 const bytes=new Uint8Array(buffer);if(bytes.length<24||bytes.length>256*1024*1024)throw Error('Choose a save smaller than 256 MB.');
 const v=new DataView(buffer),offset=String.fromCharCode(...bytes.subarray(8,11))==='CNK'?12:0;
 if(v.getUint32(offset,true)>512*1024*1024)throw Error('This world is too large for the browser importer.');
 const decoded=await decompressSav(bytes,decompress);
 return GvasFile.read(decoded.gvas,PALWORLD_TYPE_HINTS,LEVEL_CUSTOM_PROPERTIES);
}
const statKeys={'最大HP':'hp','最大SP':'stamina','攻撃力':'attack','所持重量':'weight','作業速度':'work'};
function countMap(p){return Object.fromEntries((val(p)||[]).filter(r=>typeof r.key==='string'&&Number.isInteger(r.value)&&r.value>=0).map(r=>[r.key,r.value]));}
function trueKeys(p){return (val(p)||[]).filter(r=>r.value===true).map(r=>String(r.key));}
function progress(s){
 const r=val(s.RecordData)||{},records={};
 for(const [key,label] of [['FastTravelPointUnlockFlag','Fast travel points'],['TowerBossDefeatFlag','Tower bosses'],['NormalBossDefeatFlag','Boss records'],['NoteObtainForInstanceFlag','Journals'],['RelicObtainForInstanceFlag','Relics'],['ItemPickupObtainForInstanceFlag','Pickup records']]){
  const matched=Object.keys(r).find(k=>k.startsWith(key));if(matched)records[label]=trueKeys(r[matched]).length;
 }
 return {technologies:values(s.UnlockedRecipeTechnologyNames),technologyPoints:num(s.TechnologyPoint),ancientPoints:num(s.bossTechnologyPoint),captureBonuses:countMap(r.PalCaptureBonusCount),quests:values(s.CompletedQuestArray_FullRelease),records};
}
export function extractClientProfile(save){
 const p=save.properties.SaveData?.value;if(!p?.Local_PalEncountFlag)throw Error('Choose a LocalData.sav PC cache file.');
 return {version:1,source:'client-cache',importedAt:new Date().toISOString(),player:null,captures:{},seen:trueKeys(p.Local_PalEncountFlag).map(s=>s.split('::').at(-1)),inventory:[],pals:[],warnings:['This PC cache records encountered species only. It does not contain capture counts, inventory, player stats or owned Pal builds. Encountered Pals are not marked caught.']};
}
function points(p){const out={hp:0,stamina:0,attack:0,weight:0,work:0};for(const list of ['GotStatusPointList','GotExStatusPointList'])for(const row of values(p[list])){const key=statKeys[val(row.StatusName)];if(key)out[key]+=num(row.StatusPoint);}return out;}
function slotData(slot){
 if(slot.ItemId){const id=val(slot.ItemId);return {id:val(id.StaticId),count:num(slot.StackCount),index:num(slot.SlotIndex),dynamic:uid(id.DynamicId?.value?.LocalIdInCreatedWorld)};}
 const b=values(slot.RawData);if(!b.length)return null;
 // 1.0 serialized item-slot prefix: slot index, count, static ID, dynamic world/local GUIDs.
 const r=new FReader(b instanceof Uint8Array?b:Uint8Array.from(b));
 const index=r.i32(),count=r.i32(),id=r.fstring();r.guid();const dynamic=String(r.guid());
 if(index<0||index>100000||count<0||count>100000000||id.length>256)throw Error('Unsupported item-slot layout.');
 return {id,count,index,dynamic};
}
export function extractProfile(world,player,catalog){
 const s=player.properties.SaveData?.value;
 if(!s?.PlayerUId||!s.InventoryInfo)throw Error('Choose your character file from Players.');
 const captures=countMap(val(s.RecordData)?.PalCaptureCount),seen=trueKeys(val(s.RecordData)?.PaldeckUnlockFlag),savedProgress=progress(s);
 if(!world)return {version:1,source:'character',importedAt:new Date().toISOString(),player:null,captures,seen,progress:savedProgress,inventory:[],pals:[],warnings:['Character progress imported. Inventory, player stats and individual owned Pals are only available with a matching local-world save. Saved location totals are shown separately; map checkmarks are unchanged.']};
 const ws=world.properties.worldSaveData?.value;
 if(!ws)throw Error('Choose a valid Level.sav world file.');
 const owner=uid(s.PlayerUId),characters=val(ws.CharacterSaveParameterMap);
 if(!Array.isArray(characters))throw Error('The world character records could not be read.');
 const ownPlayer=characters.find(c=>sp(c)&&val(sp(c).IsPlayer)&&uid(c.key.PlayerUId)===owner);
 if(!ownPlayer)throw Error('This player does not belong to the selected world, or its player record is unreadable.');
 const playerStats=sp(ownPlayer),warnings=[],inventory=[],inventoryInfo=val(s.InventoryInfo),containers=val(ws.ItemContainerSaveData)||[];
 for(const [kind,ref] of Object.entries(inventoryInfo)){
  const id=uid(val(ref)?.ID),container=containers.find(c=>uid(c.key.ID)===id);
  if(!container){warnings.push(kind+': container unavailable');continue;}
  for(const row of values(container.value.Slots)){try{const slot=slotData(row);if(slot?.count&&slot.id!=='None')inventory.push({id:slot.id,count:slot.count,index:slot.index,kind});}catch{throw Error('Inventory could not be read completely. The save has an unsupported item layout.');}}
 }
 const pals=[];let unreadable=0;
 for(const c of characters){const p=sp(c);if(!p){unreadable++;continue;}if(val(p.IsPlayer)||uid(p.OwnerPlayerUId)!==owner)continue;
  const rawId=val(p.CharacterID),id=rawId?.replace(/^(BOSS_|RAID_)/,'');
  const trust=num(p.FriendshipPoint),bond=catalog.bond.filter(r=>r.points<=trust).at(-1)?.rank||0;
  pals.push({id,rawId,level:num(p.Level,1),iv:{hp:num(p.Talent_HP),shotAttack:num(p.Talent_Shot),defense:num(p.Talent_Defense)},stars:Math.max(0,num(p.Rank,1)-1),bond,trust,awake:!!val(p.bIsAwakening),souls:{hp:num(p.Rank_HP),shotAttack:num(p.Rank_Attack),defense:num(p.Rank_Defence??p.Rank_Defense),craftSpeed:num(p.Rank_CraftSpeed)},passives:[...values(p.PassiveSkillList)],skills:values(p.EquipWaza).map(x=>x.split('::').at(-1))});
 }
 if(unreadable)warnings.push(`${unreadable} world character records were unreadable; owned Pal coverage may be incomplete.`);
 warnings.push('Dimensional Pal storage is not included. Weapon enchantments, current durability and temporary buffs are not yet modeled.');
 return {version:1,source:'local-world',importedAt:new Date().toISOString(),player:{level:num(playerStats.Level,1),points:points(playerStats)},captures,seen,progress:savedProgress,inventory,pals,warnings};
}
